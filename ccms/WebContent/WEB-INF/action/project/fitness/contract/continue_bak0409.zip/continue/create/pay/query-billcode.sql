SELECT nextval('seq_cc_finance')::varchar AS billcode FROM dual
