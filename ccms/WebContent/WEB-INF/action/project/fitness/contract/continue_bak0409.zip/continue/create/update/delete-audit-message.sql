DELETE FROM cc_message WHERE contractcode = ${fld:contractcode} AND issystem = 2 AND org_id = ${def:org}
